package com.dokhodyaga.vpn

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Neon = Color(0xFF39FF14)
private val Bg = Color(0xFF080B09)
private val Panel = Color(0xFF121914)
private val Muted = Color(0xFF8B998F)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DokhodyagaApp() }
    }
}

@Composable
fun DokhodyagaApp() {
    var selected by remember { mutableStateOf("Германия") }
    var configReady by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Серверная конфигурация ещё не добавлена") }
    val countries = listOf("Германия" to "🇩🇪", "Нидерланды" to "🇳🇱", "Финляндия" to "🇫🇮")

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Neon,
            onPrimary = Color.Black, onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Column(
            modifier = Modifier.fillMaxSize().background(Bg).padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(26.dp))
            Text("DOKHODYAGA", color = Neon, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Text("VPN", color = Color.White, fontSize = 14.sp, letterSpacing = 6.sp)
            Spacer(Modifier.height(38.dp))
            Box(
                modifier = Modifier.size(174.dp).background(Panel, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Box(Modifier.size(142.dp).background(Color(0xFF1B2B1D), CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = Neon, modifier = Modifier.size(54.dp))
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("НЕ ПОДКЛЮЧЕНО", color = Neon, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Spacer(Modifier.height(8.dp))
            Text(message, color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(30.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("ЛОКАЦИЯ", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text("3 региона", color = Muted, fontSize = 11.sp)
            }
            Spacer(Modifier.height(10.dp))
            countries.forEach { (name, flag) ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        .background(if (selected == name) Color(0xFF1A2A1C) else Panel, RoundedCornerShape(14.dp))
                        .clickable { selected = name }.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(flag, fontSize = 22.sp)
                    Spacer(Modifier.width(14.dp))
                    Text(name, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    if (selected == name) Icon(Icons.Default.CheckCircle, contentDescription = "Выбрано", tint = Neon)
                }
            }
            Spacer(Modifier.height(24.dp))
            Button(
                onClick = { message = if (configReady) "Ядро VPN ещё не подключено к этому проекту" else "Сначала потребуется серверная конфигурация" },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Neon),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text("ПОДКЛЮЧИТЬСЯ", color = Color.Black, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
            }
            Spacer(Modifier.weight(1f))
            Text("DOKHODYAGA VPN • ANDROID 0.1.0", color = Color(0xFF536057), fontSize = 10.sp)
        }
    }
}
